/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package emailmodel;

import email.DefaultAuthenticator;
import email.Email;
import email.EmailAttachment;
import email.EmailException;
import email.HtmlEmail;
import email.MultiPartEmail;
import email.SimpleEmail;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.activation.CommandMap;
import javax.activation.MailcapCommandMap;
import junit.framework.Assert;

import nz.ac.waikato.modeljunit.Action;
import nz.ac.waikato.modeljunit.FsmModel;
import nz.ac.waikato.modeljunit.Tester;
import nz.ac.waikato.modeljunit.QuickTester;
import nz.ac.waikato.modeljunit.LookaheadTester;
import nz.ac.waikato.modeljunit.AllRoundTester;
import nz.ac.waikato.modeljunit.coverage.TransitionPairCoverage;
import nz.ac.waikato.modeljunit.coverage.StateCoverage;
import nz.ac.waikato.modeljunit.coverage.ActionCoverage;
import nz.ac.waikato.modeljunit.coverage.TransitionCoverage;

/**
 *
 * @author Apostolos
 */

public class EmailModel implements FsmModel {
    
    public enum states{Empty, From, To, Bounce, Cc, Subj, Text, ChooseType, Simple, WithAtt, Html,
    
                        EmailReady, MailSent};

    protected states modelState = states.ChooseType;
    protected boolean empty=false, fromAddr= false, ToAddr= false, bounce = false,
            subj = false, text= false, cc = false, att= false, url= false, sent= false;
    protected int mtype=-9, sentMails=0;
    protected String type = " ";
    
    Email email = new SimpleEmail();
    MultiPartEmail email2 = new MultiPartEmail();
    HtmlEmail email3 = new HtmlEmail();

    
   
       @Override
    public String getState() {
        
            StringBuilder result = new StringBuilder();
            result = result.append(modelState.toString());
            result = result.append("\t").append(type);
            result = result.append("\t").append(sentMails);
           
          return result.toString();
    }
    /**
     *
     * @param bln
     */
    @Override
    public void reset(boolean bln) {

        modelState = states.Empty;
        empty = true;
        sentMails=0;
        fromAddr = false; ToAddr = false; subj = false; text = false;
        url = false; att = false; sent = false;
        type = " ";
        mtype = -9;
        
    }
    
    public boolean EmptyGuard(){ return modelState == states.Empty; }
    @Action public void Empty()
    {
        empty = false;
        modelState = states.ChooseType;
    }
    
    public boolean SetTypeGuard(){return (modelState == states.ChooseType && type.equals(" "));}
    @Action public void SetType() 
    {
      
        Random rint = new Random();
        mtype = rint.nextInt(3);
        switch(mtype)
        {
            case 0: modelState = states.From; type = "SimpleEmail"; System.out.println("Type = "+type);break;
            case 1: modelState = states.From; type = "EmailWithAtt"; System.out.println("Type = "+type); break;
            case 2: modelState = states.From; type = "HtmlEmail"; System.out.println("Type = "+type); break;
            default: System.out.println("Invalid number");
        }
    }
    
    public boolean SetFromGuard(){return (modelState == states.From) || (fromAddr == false);}
    @Action public void SetFrom() 
    {
        int numAt = 0;
        int numDot = 0, pos=0;
        
        try {
            email.setFrom("ux.apostolos@gmail.com");
            email2.setFrom("ux.apostolos@gmail.com");
            email3.setFrom("ux.apostolos@gmail.com");
        } catch (EmailException ex) {
           Logger.getLogger(EmailModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        fromAddr = true;
        //Assert.assertEquals("x.apostolos@gmail.com", email.getFromAddress().toString());
        int length = email.getFromAddress().toString().length();
        char charAt = email.getFromAddress().toString().charAt(0);
        char charAt2 = email.getFromAddress().toString().charAt(0);
        char charAt3 = email.getFromAddress().toString().charAt(0);
        char array[] = email.getFromAddress().toString().toCharArray();
       
      //  if(Character.isLetter(charAt)){
            
    //        System.out.println("First letter OK");
            
     //   } else {
    //        System.out.println("Invalid first character");
    //        fromAddr = false;
    //    }
        for (char ch: array) {
            
            if(ch == '@'){
                numAt++;
                if(numAt>1){ System.out.println("@ character exists more than once"); 
                fromAddr = false;}
            }
              if(ch == '.'){
                numDot++;
                System.out.println("Dot found in pos " + pos);
                if(numDot>3){ System.out.println(". character exists more than twice"); 
                fromAddr = false;}
              }
         ++pos;
        }
         Assert.assertTrue(Character.isLetter(charAt));
         Assert.assertTrue(Character.isLetter(charAt2));
         Assert.assertTrue(Character.isLetter(charAt3));

         Assert.assertTrue(length<254);
        
        /*if(length<254)
        {
            System.out.println("lENGTH OK");
        }
        else{
            System.out.println("Invalid address");
            fromAddr = false;
        }*/
        modelState = states.To;
    }
    
     public boolean SetToGuard(){return modelState == states.To || ToAddr == false;}
    @Action public void SetTo()
    {    
      
        try {
            email.addTo("bm311990@yahoo.gr");
            email2.addTo("bm311990@yahoo.gr");
            email3.addTo("bm311990@yahoo.gr");
      
        } catch (EmailException ex) {
            Logger.getLogger(EmailModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        ToAddr = true;
        modelState = states.Cc;
    }
    
    public boolean SetBounceGuard(){return modelState == states.Bounce;}
    @Action public void SetBounce()
    {
        email.setBounceAddress("aachatzop@csd.auth.gr");
        email2.setBounceAddress("aachatzop@csd.auth.gr");
        email3.setBounceAddress("aachatzop@csd.auth.gr");

        bounce = true;
        modelState = states.Subj;

    }
    public boolean SetCCGuard(){return modelState == states.Cc;}
    @Action public void SetCC()
    {
        try {
            email.addCc("bm311990@yahoo.gr");
            //Assert.assertEquals("SimpleEmail", temp.toString());
            email2.addCc("bm311990@yahoo.gr");
            email3.addCc("bm311990@yahoo.gr");


        } catch (EmailException ex) {
            Logger.getLogger(EmailModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        cc = true;
        modelState = states.Bounce;
       
    }
    
     public boolean SetSubjGuard(){return modelState == states.Subj;}
    @Action public void SetSubj() 
    { 
        email.setSubject("Simple mail");
        subj = true;
        modelState = states.Text;
        
    }
    
     public boolean SetTextGuard(){return modelState == states.Text;}
    @Action public void SetText() 
    {    
        
        try {
            email.setMsg("Hello test mail");
        } catch (EmailException ex) {
            Logger.getLogger(EmailModel.class.getName()).log(Level.SEVERE, null, ex);
        }
              switch(type)
            {
                case "SimpleEmail": modelState = states.Simple; break;
                   
                case "EmailWithAtt": modelState = states.WithAtt; break;

                case "HtmlEmail": modelState = states.Html;
                    
                default: type = " ";
            }
              text = true;
    }
    
     public boolean SimpleMailGuard(){return (modelState == states.Simple && type.equals("SimpleEmail"));}
    @Action public void SimpleMail() 
    {
        Assert.assertTrue(ToAddr);
        Assert.assertTrue(fromAddr);
        
        Assert.assertEquals("SimpleEmail", type);
        email.setHostName("smtp.gmail.com");
        email.setSmtpPort(465);
        email.setSSLOnConnect(true);
        email.setAuthenticator(new DefaultAuthenticator("x.apostolos@gmail.com", "@ax080389ax@"));
        modelState = states.EmailReady;
    }
    
     public boolean AttachMailGuard(){return (modelState == states.WithAtt && type.equals("EmailWithAtt"));}
    @Action public void AttachMail() 
    {
        att = true;
        
        EmailAttachment attachment = new EmailAttachment();
        attachment.setPath("The_new_emblem_for_PAOK_FC.jpg");
        attachment.setDisposition(EmailAttachment.ATTACHMENT);
        attachment.setDescription("PAOK_Emblem");
        attachment.setName("PAOK");
        email2.setHostName("smtp.gmail.com");
        email2.setSSLOnConnect(true);
        email2.setSmtpPort(465);
        email2.setAuthenticator(new DefaultAuthenticator("x.apostolos@gmail.com", "@ax080389ax@"));
        Assert.assertEquals("EmailWithAtt", type);
        
        try {
          //  email2.addTo("bm311990@yahoo.gr", "barbara");
          //  Assert.assertEquals("bm311990@yahoo.gr", email2.getToAddresses().toString());
            email2.addCc("bm311990@yahoo.gr");
         
        } catch (EmailException ex) {
            Logger.getLogger(EmailModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        email2.setSubject("The picture");
        try {
            email2.setMsg("Here is the picture you wanted");
        } catch (EmailException ex) {
            Logger.getLogger(EmailModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            email2.attach(attachment);
        } catch (EmailException ex) {
            Logger.getLogger(EmailModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        modelState = states.EmailReady;
    }
    
     public boolean HtmlMailGuard(){return (modelState == states.Html && type.equals("HtmlEmail"));}
    @Action public void HtmlMail() 
    {
        try {
            url = true;
            Assert.assertEquals("HtmlEmail", type);
            
            email3.setHostName("smtp.gmail.com");
            email3.setSmtpPort(465);
            email3.setSSLOnConnect(true);
            email3.setAuthenticator(new DefaultAuthenticator("x.apostolos@gmail.com", "@ax080389ax@"));
            
            try {
                email3.addTo("bm311990@yahoo.gr");
                email3.addCc("bm311990@yahoo.gr");
            
            } catch (EmailException ex) {
                Logger.getLogger(EmailModel.class.getName()).log(Level.SEVERE, null, ex);
            }
          
            email3.setSubject("Test email with inline image");
           // Assert.assertTrue(Character.isLetter(email3.getFromAddress().toString().charAt(0)));
            
            // embed the image and get the content id
            URL icon = null;
            try {
                icon = new URL("http://www.apache.org/images/asf_logo_wide.gif");
            } catch (MalformedURLException ex) {
                Logger.getLogger(EmailModel.class.getName()).log(Level.SEVERE, null, ex);
            }
            String cid = email3.embed(icon, "Apache logo");
            
            // set the html message
            email3.setHtmlMsg("<html>The apache logo - <img src=\"cid:"+cid+"\"></html>");
            
            // set the alternative message
            email3.setTextMsg("Your email client does not support HTML messages");
        } catch (EmailException ex) {
            Logger.getLogger(EmailModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        modelState = states.EmailReady;
    }
    
    public boolean sendEmailGuard(){return modelState == states.EmailReady;}
    @Action public void sendEmail()
    {
        System.out.println("Sending......");
        try {
            sent = true;
            Date mdate = email.getSentDate();
            Assert.assertEquals(mdate.getTime(), System.currentTimeMillis());
            Date mdate2 = email.getSentDate();
            Assert.assertEquals(mdate2.getTime(), System.currentTimeMillis());
            Date mdate3 = email.getSentDate();
            Assert.assertEquals(mdate3.getTime(), System.currentTimeMillis());
            switch(type)
            {
                case "SimpleEmail": email.send(); System.out.println(++sentMails + "Emails sent successfully at "); break;
                case "EmailWithAtt": email2.send(); System.out.println(++sentMails + "Emails sent successfully"); break;
                case "HtmlEmail": email3.send(); System.out.println(++sentMails + "Emails sent successfully"); break;
                default: System.out.println("Invalid type");
            }
            
            
        } catch (EmailException ex) {
            Logger.getLogger(EmailModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        modelState = states.MailSent;
        System.out.println(sentMails + " Emails sent");
        //reset(true);
    }
    
     public static void main(String[] args) {
             
         MailcapCommandMap mcap = new MailcapCommandMap(); 
         mcap.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain"); 
         mcap.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html");
         mcap.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml"); 
         mcap.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed; x-java-fallback-entry=true"); 
         mcap.addMailcap("message/rfc822;; x-java-content-handler=com.sun.mail.handlers.message_rfc822"); 
         CommandMap.setDefaultCommandMap(mcap);

            EmailModel mymodel = new EmailModel();
            Tester myTester = new LookaheadTester(mymodel);
            myTester.addListener("verbose");
            TransitionPairCoverage tpc=  new TransitionPairCoverage();
            myTester.addCoverageMetric(tpc);
            StateCoverage sc = new StateCoverage();
            myTester.addCoverageMetric(sc);
            TransitionCoverage tc = new TransitionCoverage();
            myTester.addCoverageMetric(tc);
            
            myTester.generate(2000);
           // System.out.println(tpc.getCoverage());
            myTester.printCoverage();
            System.out.println("2000 tests printed");
          
    }
    
}
